﻿using System.ComponentModel.DataAnnotations;

namespace PetroConnect.Data.Context
{
    public class TestData
    {
        
        [Key]
        public int EmpId { get; set; }
        public string EmpName { get; set; }

        public string Address { get; set; }
    }

    [Keyless]
    public class SpCustomerRegistration_Result
    {
        public bool Status { get; set; }
    }
}